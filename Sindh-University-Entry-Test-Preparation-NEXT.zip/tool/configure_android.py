from pathlib import Path
import shutil

source = Path('google-services.json')
target = Path('android/app/google-services.json')
target.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(source, target)

settings = Path('android/settings.gradle.kts')
s = settings.read_text()
if 'com.google.gms.google-services' not in s:
    s = s.replace(
        'plugins {',
        'plugins {\n    id("com.google.gms.google-services") version "4.4.2" apply false',
        1,
    )
settings.write_text(s)

app = Path('android/app/build.gradle.kts')
a = app.read_text()
if 'com.google.gms.google-services' not in a:
    a = a.replace('plugins {', 'plugins {\n    id("com.google.gms.google-services")', 1)
app.write_text(a)

manifest = Path('android/app/src/main/AndroidManifest.xml')
m = manifest.read_text()
if 'android.permission.RECORD_AUDIO' not in m:
    pos = m.find('>')
    permissions = (
        '\n    <uses-permission android:name="android.permission.INTERNET" />'
        '\n    <uses-permission android:name="android.permission.RECORD_AUDIO" />'
    )
    m = m[:pos + 1] + permissions + m[pos + 1:]
manifest.write_text(m)
