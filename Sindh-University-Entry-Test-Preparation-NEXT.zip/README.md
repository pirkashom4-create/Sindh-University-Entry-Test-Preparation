# Sindh University Entry Test Preparation

Flutter Android source project. App creator credit: **Om Pirkash**.

## Included in this source package
- Blue-and-white student/admin preview UI
- Firebase Core initialization scaffold and Firebase AI Logic text assistant scaffold
- Voice input (speech-to-text) and spoken answers (text-to-speech) scaffold
- Android launcher icon asset and launcher-icon configuration
- Firebase Android configuration file (`google-services.json`)

## Important status
This is a development preview, not a finished production app. Student/admin authentication, role permissions, Firestore-backed MCQs/tests/results, payment verification, notifications, and the full admin web portal are not yet implemented. Firebase AI Logic also requires the project-side setup and App Check configuration before live AI use. Do not publish this preview as a complete service.

## Build
Use the GitHub Actions workflow in `.github/workflows/android-apk.yml`. It extracts the source ZIP from the repository, creates the Android platform folder, configures Firebase, generates the launcher icon, and builds a release APK.
