# Sindh University Entry Test Preparation

Flutter Android starter updated with Firebase AI Logic text chat and device speech input/output.

## Firebase project
- Firebase project ID: `sindh-university-entry-test`
- Android application ID: `com.sindhuniversity.entrytest`
- Firebase Android config is included at `android/app/google-services.json` after Android scaffolding is generated. The root copy `google-services.json` is used by the GitHub Actions workflow.

## Included in this update
- Firebase Core initialization
- Firebase AI Logic (`firebase_ai`) using the Gemini Developer API and model `gemini-3.8-flash`
- Firebase App Check: debug provider for debug builds, Play Integrity for release builds
- Urdu/English language choice and automatic same-language response instruction
- Device speech-to-text microphone input and text-to-speech playback

## Important setup notes
1. Firebase AI Logic and AI Monitoring were enabled in the Firebase Console for the existing project.
2. App Check is enforced for Firebase AI Logic. For local/debug builds, run the app once and register the App Check debug token shown in Android logs in Firebase Console > App Check. For production, configure Play Integrity and distribute through a supported Google Play track. A release APK installed directly may not pass Play Integrity until the app is configured appropriately.
3. This is an AI integration preview, not a production-ready student portal. Login buttons still open preview dashboards. Admin authorization, quotas (10/100 per day), secure role checks, payments, database-backed content and server-side abuse controls are not implemented yet. Do not use the preview admin entry point for real administration.
4. Speech recognition and voice playback depend on the Android device's installed speech services and available Urdu/English voices.
5. Never put a Gemini API key in the app. Firebase AI Logic is used through the Firebase project.

## Build with GitHub Actions
Push this project to a GitHub repository on the `main` branch, then open Actions > Build Android APK > Run workflow. The workflow creates the Android project, configures Google Services, and uploads the release APK as an artifact.

## Local build
Install Flutter and Android SDK, then run `flutter pub get` and `flutter build apk --release` after generating the Android platform and configuring the Google Services Gradle plugin as in the workflow.
