import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_ai/firebase_ai.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
    await FirebaseAppCheck.instance.activate(
      androidProvider: kReleaseMode ? AndroidProvider.playIntegrity : AndroidProvider.debug,
    );
  } catch (e) {
    debugPrint('Firebase initialization issue: $e');
  }
  runApp(const SUEntryApp());
}

const navy = Color(0xFF123B70);
const blue = Color(0xFF1769AA);

class SUEntryApp extends StatelessWidget {
  const SUEntryApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Sindh University Entry Test Preparation',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: blue), useMaterial3: true, scaffoldBackgroundColor: const Color(0xFFF4F7FB)),
    home: const WelcomePage(),
  );
}

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Padding(padding: const EdgeInsets.all(24), child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Spacer(),
        Container(height: 100, width: 100, decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(28)), child: const Icon(Icons.school, color: Colors.white, size: 58)),
        const SizedBox(height: 24),
        const Text('Sindh University', textAlign: TextAlign.center, style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: navy)),
        const Text('Entry Test Preparation', textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        const Text('Prepare smarter. Practice better. Achieve your goals.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
        const Spacer(),
        FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage(isAdmin: false))), icon: const Icon(Icons.person), label: const Text('Student Login / Register'), style: FilledButton.styleFrom(padding: const EdgeInsets.all(16))),
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage(isAdmin: true))), icon: const Icon(Icons.admin_panel_settings), label: const Text('Admin Login'), style: OutlinedButton.styleFrom(padding: const EdgeInsets.all(16))),
        const SizedBox(height: 18),
        const Text('Independent preparation platform • Not an official University of Sindh app', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.black45)),
      ],
    ))),
  );
}

class LoginPage extends StatefulWidget {
  final bool isAdmin;
  const LoginPage({super.key, required this.isAdmin});
  @override
  State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  @override
  void dispose() { email.dispose(); password.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(widget.isAdmin ? 'Admin Login' : 'Student Login')),
    body: ListView(padding: const EdgeInsets.all(22), children: [
      const SizedBox(height: 24),
      Text(widget.isAdmin ? 'Admin Portal' : 'Welcome Student', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: navy)),
      const SizedBox(height: 20),
      TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email address', prefixIcon: Icon(Icons.email), border: OutlineInputBorder())),
      const SizedBox(height: 14),
      TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock), border: OutlineInputBorder())),
      const SizedBox(height: 20),
      FilledButton(onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => DashboardPage(isAdmin: widget.isAdmin))), child: Text(widget.isAdmin ? 'Continue to Admin Preview' : 'Continue to Student Preview')),
      if (!widget.isAdmin) TextButton(onPressed: () => showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Student Registration'), content: const Text('Registration will be enabled after secure cloud authentication is connected.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))])), child: const Text('Create student account')),
      const SizedBox(height: 12),
      const Text('Preview build: secure sign-in and account creation are not connected yet.', style: TextStyle(color: Colors.deepOrange, fontSize: 12)),
    ]));
}

class DashboardPage extends StatelessWidget {
  final bool isAdmin;
  const DashboardPage({super.key, required this.isAdmin});
  @override
  Widget build(BuildContext context) {
    final items = isAdmin ? [
      ('Students', Icons.people), ('MCQs & Question Bank', Icons.quiz), ('Study Material / PDFs', Icons.picture_as_pdf), ('Create Quiz & Mock Test', Icons.timer), ('Results & Merit Lists', Icons.leaderboard), ('University Updates', Icons.campaign), ('Payment Approvals', Icons.payments), ('Admin Accounts & Permissions', Icons.admin_panel_settings), ('Admin AI Assistant', Icons.auto_awesome),
    ] : [
      ('Study Material', Icons.menu_book), ('Subject-wise MCQs', Icons.quiz), ('Practice Quiz', Icons.checklist), ('Full Mock Test', Icons.timer), ('My Results', Icons.bar_chart), ('Merit List', Icons.emoji_events), ('University Latest Updates', Icons.campaign), ('Free & Premium Courses', Icons.workspace_premium), ('AI Study Assistant', Icons.auto_awesome),
    ];
    return Scaffold(appBar: AppBar(title: Text(isAdmin ? 'Admin Dashboard' : 'Student Dashboard'), backgroundColor: Colors.white), body: ListView(padding: const EdgeInsets.all(16), children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(20)), child: Text(isAdmin ? 'Manage your preparation portal' : 'Your entry test preparation starts here', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold))),
      const SizedBox(height: 16),
      GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: items.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.22), itemBuilder: (context, i) => Card(elevation: 1, child: InkWell(borderRadius: BorderRadius.circular(12), onTap: () { if (items[i].$1.contains('AI Assistant')) { Navigator.push(context, MaterialPageRoute(builder: (_) => AiAssistantPage(isAdmin: isAdmin))); } else { showDialog(context: context, builder: (_) => AlertDialog(title: Text(items[i].$1), content: const Text('This module will be connected to the live cloud system in the next development phase.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))])); } }, child: Padding(padding: const EdgeInsets.all(12), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(items[i].$2, size: 32, color: blue), const SizedBox(height: 10), Text(items[i].$1, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600))]))))),
      const SizedBox(height: 12),
      const Text('Preview only: live database, publishing, payments, notifications and test scoring are not yet configured.', style: TextStyle(fontSize: 12, color: Colors.deepOrange)),
    ]));
  }
}


class AiAssistantPage extends StatefulWidget {
  final bool isAdmin;
  const AiAssistantPage({super.key, required this.isAdmin});
  @override
  State<AiAssistantPage> createState() => _AiAssistantPageState();
}

class _AiAssistantPageState extends State<AiAssistantPage> {
  final input = TextEditingController();
  final messages = <(bool, String)>[];
  final speech = stt.SpeechToText();
  final tts = FlutterTts();
  bool busy = false;
  bool listening = false;
  bool firebaseReady = Firebase.apps.isNotEmpty;
  String language = 'auto';
  late final GenerativeModel model;

  @override
  void initState() {
    super.initState();
    model = FirebaseAI.googleAI().generativeModel(
      model: 'gemini-3.8-flash',
      systemInstruction: Content.system(
        widget.isAdmin
          ? 'You are the administrative assistant for Sindh University Entry Test Preparation. Help admins draft original MCQs, explanations, study notes, quiz outlines and summaries of notices. Never invent official University of Sindh announcements, dates, results or merit lists. Clearly label generated educational content as a draft. Reply in the language used by the admin, Urdu or English.'
          : 'You are a friendly tutor for Sindh University entry test preparation. Explain concepts simply, solve practice questions step by step, create study plans and explain MCQs. Do not claim to be the official University of Sindh. Never invent official admission dates or results. Reply in the language used by the student, Urdu or English. If the student asks in Urdu, answer in Urdu; if English, answer in English.'
      ),
    );
    _setTtsLanguage();
  }

  @override
  void dispose() {
    input.dispose();
    tts.stop();
    super.dispose();
  }

  Future<void> _setTtsLanguage() async {
    await tts.setLanguage(language == 'ur' ? 'ur-PK' : 'en-US');
    await tts.setSpeechRate(0.45);
  }

  Future<void> _speak(String text) async {
    await _setTtsLanguage();
    await tts.speak(text);
  }

  Future<void> _listen() async {
    if (busy) return;
    if (listening) {
      await speech.stop();
      if (mounted) setState(() => listening = false);
      return;
    }
    final available = await speech.initialize(
      onStatus: (status) { if (mounted && (status == 'done' || status == 'notListening')) setState(() => listening = false); },
      onError: (error) { if (mounted) { setState(() => listening = false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Microphone error: ${error.errorMsg}'))); } },
    );
    if (!available) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Speech recognition is not available on this device.')));
      return;
    }
    setState(() => listening = true);
    await speech.listen(
      localeId: language == 'ur' ? 'ur_PK' : 'en_US',
      onResult: (result) { if (mounted) setState(() => input.text = result.recognizedWords); },
    );
  }

  Future<void> send() async {
    final question = input.text.trim();
    if (question.isEmpty || busy) return;
    if (!Firebase.apps.isNotEmpty) {
      setState(() => messages.add((false, 'Firebase is not configured yet. Check that android/app/google-services.json is included and rebuild the app.')));
      return;
    }
    setState(() { messages.add((true, question)); input.clear(); busy = true; });
    try {
      final langInstruction = language == 'ur'
        ? 'Answer in Urdu using clear, easy Urdu.'
        : language == 'en'
          ? 'Answer in English using simple language.'
          : 'Detect the language of the question and reply in the same language (Urdu or English).';
      final response = await model.generateContent([
        Content.text('$langInstruction\n\n${widget.isAdmin ? 'Admin request:' : 'Student question:'} $question'),
      ]);
      final answer = response.text?.trim();
      if (answer == null || answer.isEmpty) throw Exception('The AI returned an empty response.');
      if (mounted) setState(() => messages.add((false, answer)));
    } catch (e) {
      if (mounted) setState(() => messages.add((false, 'AI request failed: $e\n\nPlease check internet, Firebase AI Logic setup, and App Check configuration.')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.isAdmin ? 'Admin AI Assistant' : 'AI Study Assistant'),
      actions: [
        Padding(padding: const EdgeInsets.only(right: 10), child: DropdownButtonHideUnderline(child: DropdownButton<String>(
          value: language,
          items: const [DropdownMenuItem(value: 'auto', child: Text('Auto')), DropdownMenuItem(value: 'ur', child: Text('اردو')), DropdownMenuItem(value: 'en', child: Text('English'))],
          onChanged: (value) { if (value != null) { setState(() => language = value); _setTtsLanguage(); } },
        ))),
      ],
    ),
    body: Column(children: [
      Container(width: double.infinity, padding: const EdgeInsets.all(14), color: const Color(0xFFEAF2FB), child: Text(
        widget.isAdmin
          ? 'Admin AI: draft MCQs, explanations, notes and summaries. Verify official notices before publishing.'
          : 'Ask entry-test questions in Urdu or English. Use the microphone to speak and the speaker button to hear answers.',
        style: const TextStyle(color: navy),
      )),
      Expanded(child: messages.isEmpty
        ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Ask your first question.\n\nAI answers require internet and Firebase AI Logic access.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54))))
        : ListView.builder(padding: const EdgeInsets.all(12), itemCount: messages.length, itemBuilder: (context, i) => Align(
          alignment: messages[i].$1 ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(margin: const EdgeInsets.symmetric(vertical: 5), padding: const EdgeInsets.all(12), constraints: const BoxConstraints(maxWidth: 320), decoration: BoxDecoration(color: messages[i].$1 ? const Color(0xFFDCEBFA) : Colors.white, borderRadius: BorderRadius.circular(14)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SelectableText(messages[i].$2),
            if (!messages[i].$1) Align(alignment: Alignment.centerRight, child: IconButton(tooltip: 'Listen', onPressed: () => _speak(messages[i].$2), icon: const Icon(Icons.volume_up, color: blue))),
          ])),
        )),
      ),
      if (busy) const Padding(padding: EdgeInsets.all(8), child: LinearProgressIndicator()),
      SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(10, 8, 10, 10), child: Row(children: [
        IconButton.filledTonal(onPressed: busy ? null : _listen, tooltip: listening ? 'Stop recording' : 'Speak question', icon: Icon(listening ? Icons.mic : Icons.mic_none)),
        const SizedBox(width: 6),
        Expanded(child: TextField(controller: input, minLines: 1, maxLines: 4, enabled: !busy, decoration: const InputDecoration(hintText: 'Type your question...', border: OutlineInputBorder()))),
        const SizedBox(width: 6),
        IconButton.filled(onPressed: busy ? null : send, icon: const Icon(Icons.send)),
      ]))),
    ]),
  );
}
