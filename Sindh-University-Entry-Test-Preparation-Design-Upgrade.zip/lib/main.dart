import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_ai/firebase_ai.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
  } catch (e) {
    debugPrint('Firebase initialization issue: $e');
  }
  runApp(const SUEntryApp());
}

const navy = Color(0xFF102A56);
const blue = Color(0xFF2563C7);
const sky = Color(0xFFEAF2FF);
const gold = Color(0xFFFFC857);

class SUEntryApp extends StatelessWidget {
  const SUEntryApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Sindh University Entry Test Preparation',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.light), useMaterial3: true, scaffoldBackgroundColor: const Color(0xFFF5F8FE), fontFamily: 'Roboto', appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF5F8FE), foregroundColor: navy, elevation: 0, centerTitle: false), cardTheme: CardThemeData(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: const BorderSide(color: Color(0xFFE6EDF7)))), inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFFDCE5F2))), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFFDCE5F2))), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: blue, width: 1.6))),),
    home: const WelcomePage(),
  );
}

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Container(
      decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF102A56), Color(0xFF1C55A0), Color(0xFF347FD0)])),
      child: SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(24, 22, 24, 20), child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(children: [Container(height: 42, width: 42, decoration: BoxDecoration(color: Colors.white.withOpacity(.15), borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.school_rounded, color: Colors.white)), const SizedBox(width: 10), const Expanded(child: Text('SU ENTRY PREP', style: TextStyle(color: Colors.white, letterSpacing: 1.5, fontWeight: FontWeight.w800))) ]),
          const Spacer(),
          Center(child: Container(height: 132, width: 132, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(36), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.18), blurRadius: 28, offset: const Offset(0, 12))]), child: ClipRRect(borderRadius: BorderRadius.circular(26), child: Image.asset('assets/icon/app_icon.png', fit: BoxFit.cover)))),
          const SizedBox(height: 28),
          const Text('Sindh University', textAlign: TextAlign.center, style: TextStyle(fontSize: 31, height: 1.1, fontWeight: FontWeight.w900, color: Colors.white)),
          const SizedBox(height: 8),
          const Text('ENTRY TEST PREPARATION', textAlign: TextAlign.center, style: TextStyle(fontSize: 15, letterSpacing: 2.2, fontWeight: FontWeight.w700, color: Color(0xFFFFD36E))),
          const SizedBox(height: 14),
          Text('Prepare smarter. Practice better. Achieve your goals.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(.86), fontSize: 14)),
          const SizedBox(height: 28),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [ _welcomeTag(Icons.quiz_outlined, 'MCQs'), const SizedBox(width: 8), _welcomeTag(Icons.timer_outlined, 'Mock Tests'), const SizedBox(width: 8), _welcomeTag(Icons.auto_awesome, 'AI Tutor') ]),
          const Spacer(),
          FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage(isAdmin: false))), icon: const Icon(Icons.person_rounded), label: const Text('Student Login / Register'), style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: navy, padding: const EdgeInsets.symmetric(vertical: 18), textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)))),
          const SizedBox(height: 12),
          OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage(isAdmin: true))), icon: const Icon(Icons.admin_panel_settings_rounded), label: const Text('Admin Login'), style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: BorderSide(color: Colors.white.withOpacity(.55)), padding: const EdgeInsets.symmetric(vertical: 17), textStyle: const TextStyle(fontWeight: FontWeight.w700), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)))),
          const SizedBox(height: 22),
          Text('Independent preparation platform • Not an official University of Sindh app', textAlign: TextAlign.center, style: TextStyle(fontSize: 10, color: Colors.white.withOpacity(.65))),
          const SizedBox(height: 7),
          const Text('Created by Om Pirkash', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Color(0xFFFFD36E), fontWeight: FontWeight.w800)),
        ],
      ))),
    ),
  );
}

Widget _welcomeTag(IconData icon, String label) => Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8), decoration: BoxDecoration(color: Colors.white.withOpacity(.13), borderRadius: BorderRadius.circular(30), border: Border.all(color: Colors.white.withOpacity(.2))), child: Row(children: [Icon(icon, size: 14, color: Colors.white), const SizedBox(width: 5), Text(label, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600))]));

class LoginPage extends StatefulWidget {
  final bool isAdmin;
  const LoginPage({super.key, required this.isAdmin});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  final fullName = TextEditingController();
  bool loading = false;
  bool registering = false;
  @override
  void dispose() { email.dispose(); password.dispose(); fullName.dispose(); super.dispose(); }

  Future<void> submit() async {
    final e = email.text.trim().toLowerCase();
    final pw = password.text;
    if (e.isEmpty || !e.contains('@') || pw.length < 6 || (registering && fullName.text.trim().isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid email, password (minimum 6 characters), and name for registration.'))); return;
    }
    setState(() => loading = true);
    try {
      if (widget.isAdmin && registering) throw Exception('Admin self-registration is disabled. Ask the Super Admin to create your account.');
      UserCredential credential;
      if (registering) {
        credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: e, password: pw);
        await credential.user!.updateDisplayName(fullName.text.trim());
        await FirebaseFirestore.instance.collection('students').doc(credential.user!.uid).set({
          'uid': credential.user!.uid, 'fullName': fullName.text.trim(), 'email': e, 'status': 'active',
          'membership': 'free', 'preferredLanguage': 'en', 'createdAt': FieldValue.serverTimestamp(),
        });
      } else {
        credential = await FirebaseAuth.instance.signInWithEmailAndPassword(email: e, password: pw);
      }
      if (widget.isAdmin) {
        final doc = await FirebaseFirestore.instance.collection('admins').doc(credential.user!.uid).get();
        final data = doc.data();
        if (!doc.exists || data?['active'] != true || data?['role'] == null) {
          await FirebaseAuth.instance.signOut();
          throw Exception('Not authorized as an active admin. Super Admin must assign your role first.');
        }
      } else {
        final ref = FirebaseFirestore.instance.collection('students').doc(credential.user!.uid);
        final doc = await ref.get();
        if (!doc.exists) await ref.set({'uid': credential.user!.uid, 'fullName': credential.user!.displayName ?? '', 'email': e, 'status': 'active', 'membership': 'free', 'createdAt': FieldValue.serverTimestamp()});
        if (doc.data()?['status'] == 'blocked') { await FirebaseAuth.instance.signOut(); throw Exception('Your account is blocked. Contact the administrator.'); }
      }
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => DashboardPage(isAdmin: widget.isAdmin)));
    } on FirebaseAuthException catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? e.code)));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.isAdmin ? 'Admin Login' : (registering ? 'Student Registration' : 'Student Login'))),
    body: ListView(padding: const EdgeInsets.all(22), children: [
      const SizedBox(height: 24),
      Text(widget.isAdmin ? 'Admin Portal' : 'Welcome Student', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: navy)),
      const SizedBox(height: 20),
      if (registering && !widget.isAdmin) ...[TextField(controller: fullName, decoration: const InputDecoration(labelText: 'Full name', prefixIcon: Icon(Icons.person), border: OutlineInputBorder())), const SizedBox(height: 14)],
      TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email address', prefixIcon: Icon(Icons.email), border: OutlineInputBorder())),
      const SizedBox(height: 14),
      TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password (minimum 6 characters)', prefixIcon: Icon(Icons.lock), border: OutlineInputBorder())),
      const SizedBox(height: 20),
      FilledButton(onPressed: loading ? null : submit, child: loading ? const CircularProgressIndicator() : Text(registering ? 'Create Student Account' : 'Sign In')),
      if (!widget.isAdmin) TextButton(onPressed: loading ? null : () => setState(() => registering = !registering), child: Text(registering ? 'Already registered? Sign in' : 'Create student account')),
      if (widget.isAdmin) const Padding(padding: EdgeInsets.only(top: 12), child: Text('Admin accounts must be created by the Super Admin. Self-registration is disabled.', style: TextStyle(color: Colors.black54, fontSize: 12))),
    ]),
  );
}

class DashboardPage extends StatelessWidget {
  final bool isAdmin;
  const DashboardPage({super.key, required this.isAdmin});
  @override
  Widget build(BuildContext context) {
    final items = isAdmin ? [
      ('Students', Icons.people_alt_rounded), ('MCQs & Question Bank', Icons.quiz_rounded), ('Study Material / PDFs', Icons.picture_as_pdf_rounded), ('Create Quiz & Mock Test', Icons.timer_rounded), ('Results & Merit Lists', Icons.leaderboard_rounded), ('University Updates', Icons.campaign_rounded), ('Payment Approvals', Icons.payments_rounded), ('Admin Accounts & Permissions', Icons.admin_panel_settings_rounded), ('Admin AI Assistant', Icons.auto_awesome_rounded),
    ] : [
      ('Study Material', Icons.menu_book_rounded), ('Subject-wise MCQs', Icons.quiz_rounded), ('Practice Quiz', Icons.checklist_rounded), ('Full Mock Test', Icons.timer_rounded), ('My Results', Icons.bar_chart_rounded), ('Merit List', Icons.emoji_events_rounded), ('University Latest Updates', Icons.campaign_rounded), ('Free & Premium Courses', Icons.workspace_premium_rounded), ('AI Study Assistant', Icons.auto_awesome_rounded),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(isAdmin ? 'Admin Portal' : 'Student Portal', style: const TextStyle(fontWeight: FontWeight.w800)), actions: [IconButton(onPressed: () async { await FirebaseAuth.instance.signOut(); if (context.mounted) Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const WelcomePage()), (_) => false); }, icon: const Icon(Icons.logout_rounded), tooltip: 'Sign out')]),
      body: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 24), children: [
        Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(gradient: const LinearGradient(colors: [navy, Color(0xFF286BC0)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(26), boxShadow: [BoxShadow(color: navy.withOpacity(.18), blurRadius: 20, offset: const Offset(0, 9))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Container(height: 42, width: 42, decoration: BoxDecoration(color: Colors.white.withOpacity(.15), borderRadius: BorderRadius.circular(14)), child: Icon(isAdmin ? Icons.admin_panel_settings_rounded : Icons.school_rounded, color: Colors.white, size: 24)), const Spacer(), const Icon(Icons.waving_hand_rounded, color: gold)]),
          const SizedBox(height: 18), Text(isAdmin ? 'Welcome, Administrator' : 'Welcome to your study space', style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
          const SizedBox(height: 7), Text(isAdmin ? 'Manage learning content and student progress.' : 'Small daily practice. Big exam-day confidence.', style: TextStyle(color: Colors.white.withOpacity(.84), fontSize: 13)),
          const SizedBox(height: 17), Row(children: [ _dashPill(Icons.auto_awesome, isAdmin ? 'Admin tools' : 'AI Study Tutor'), const SizedBox(width: 8), _dashPill(Icons.language, 'Urdu + English') ]),
        ])),
        const SizedBox(height: 23),
        Row(children: [const Expanded(child: Text('Your workspace', style: TextStyle(fontSize: 19, color: navy, fontWeight: FontWeight.w900))), Text('${items.length} modules', style: const TextStyle(color: Colors.black45, fontSize: 12))]),
        const SizedBox(height: 13),
        GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: items.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.08), itemBuilder: (context, i) => Card(child: InkWell(borderRadius: BorderRadius.circular(22), onTap: () { if (items[i].$1.contains('AI Assistant')) { Navigator.push(context, MaterialPageRoute(builder: (_) => AiAssistantPage(isAdmin: isAdmin))); } else { showDialog(context: context, builder: (_) => AlertDialog(title: Text(items[i].$1), content: const Text('This module will be connected to the live cloud system in the next development phase.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))])); } }, child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Container(height: 43, width: 43, decoration: BoxDecoration(color: sky, borderRadius: BorderRadius.circular(14)), child: Icon(items[i].$2, size: 23, color: blue)), const SizedBox(height: 8), Row(children: [Expanded(child: Text(items[i].$1, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: navy))), const Icon(Icons.arrow_forward_ios_rounded, size: 12, color: Colors.black38)])]))))),
        const SizedBox(height: 15),
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFFFF7E6), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFFFE4A8))), child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.info_outline_rounded, color: Color(0xFF9B6A0B), size: 18), SizedBox(width: 9), Expanded(child: Text('Preview status: some modules are still being connected to the live cloud system.', style: TextStyle(fontSize: 12, color: Color(0xFF805A12), height: 1.4))) ])),
        const SizedBox(height: 16), const Center(child: Text('Created by Om Pirkash', style: TextStyle(fontSize: 11, color: Colors.black45, fontWeight: FontWeight.w600))),
      ]),
    );
  }
}

Widget _dashPill(IconData icon, String text) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7), decoration: BoxDecoration(color: Colors.white.withOpacity(.14), borderRadius: BorderRadius.circular(30)), child: Row(children: [Icon(icon, size: 14, color: Colors.white), const SizedBox(width: 6), Text(text, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700))]));


class AiAssistantPage extends StatefulWidget {
  final bool isAdmin;
  const AiAssistantPage({super.key, required this.isAdmin});
  @override
  State<AiAssistantPage> createState() => _AiAssistantPageState();
}

class _AiAssistantPageState extends State<AiAssistantPage> {
  final input = TextEditingController();
  final messages = <(bool, String)>[];
  final speech = stt.SpeechToText();
  final tts = FlutterTts();
  bool busy = false;
  bool listening = false;
  bool firebaseReady = Firebase.apps.isNotEmpty;
  String language = 'auto';
  late final GenerativeModel model;

  @override
  void initState() {
    super.initState();
    model = FirebaseAI.googleAI().generativeModel(
      model: 'gemini-3.8-flash',
      systemInstruction: Content.system(
        widget.isAdmin
          ? 'You are the administrative assistant for Sindh University Entry Test Preparation. Help admins draft original MCQs, explanations, study notes, quiz outlines and summaries of notices. Never invent official University of Sindh announcements, dates, results or merit lists. Clearly label generated educational content as a draft. Reply in the language used by the admin, Urdu or English.'
          : 'You are a friendly tutor for Sindh University entry test preparation. Explain concepts simply, solve practice questions step by step, create study plans and explain MCQs. Do not claim to be the official University of Sindh. Never invent official admission dates or results. Reply in the language used by the student, Urdu or English. If the student asks in Urdu, answer in Urdu; if English, answer in English.'
      ),
    );
    _setTtsLanguage();
  }

  @override
  void dispose() {
    input.dispose();
    tts.stop();
    super.dispose();
  }

  Future<void> _setTtsLanguage() async {
    await tts.setLanguage(language == 'ur' ? 'ur-PK' : 'en-US');
    await tts.setSpeechRate(0.45);
  }

  Future<void> _speak(String text) async {
    await _setTtsLanguage();
    await tts.speak(text);
  }

  Future<void> _listen() async {
    if (busy) return;
    if (listening) {
      await speech.stop();
      if (mounted) setState(() => listening = false);
      return;
    }
    final available = await speech.initialize(
      onStatus: (status) { if (mounted && (status == 'done' || status == 'notListening')) setState(() => listening = false); },
      onError: (error) { if (mounted) { setState(() => listening = false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Microphone error: ${error.errorMsg}'))); } },
    );
    if (!available) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Speech recognition is not available on this device.')));
      return;
    }
    setState(() => listening = true);
    await speech.listen(
      localeId: language == 'ur' ? 'ur_PK' : 'en_US',
      onResult: (result) { if (mounted) setState(() => input.text = result.recognizedWords); },
    );
  }

  Future<void> send() async {
    final question = input.text.trim();
    if (question.isEmpty || busy) return;
    if (!Firebase.apps.isNotEmpty) {
      setState(() => messages.add((false, 'Firebase is not configured yet. Check that android/app/google-services.json is included and rebuild the app.')));
      return;
    }
    setState(() { messages.add((true, question)); input.clear(); busy = true; });
    try {
      final langInstruction = language == 'ur'
        ? 'Answer in Urdu using clear, easy Urdu.'
        : language == 'en'
          ? 'Answer in English using simple language.'
          : 'Detect the language of the question and reply in the same language (Urdu or English).';
      final response = await model.generateContent([
        Content.text('$langInstruction\n\n${widget.isAdmin ? 'Admin request:' : 'Student question:'} $question'),
      ]);
      final answer = response.text?.trim();
      if (answer == null || answer.isEmpty) throw Exception('The AI returned an empty response.');
      if (mounted) setState(() => messages.add((false, answer)));
    } catch (e) {
      if (mounted) setState(() => messages.add((false, 'AI request failed: $e\n\nPlease check internet, Firebase AI Logic setup, and App Check configuration.')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.isAdmin ? 'Admin AI Assistant' : 'AI Study Assistant'),
      actions: [
        Padding(padding: const EdgeInsets.only(right: 10), child: DropdownButtonHideUnderline(child: DropdownButton<String>(
          value: language,
          items: const [DropdownMenuItem(value: 'auto', child: Text('Auto')), DropdownMenuItem(value: 'ur', child: Text('اردو')), DropdownMenuItem(value: 'en', child: Text('English'))],
          onChanged: (value) { if (value != null) { setState(() => language = value); _setTtsLanguage(); } },
        ))),
      ],
    ),
    body: Column(children: [
      Container(width: double.infinity, padding: const EdgeInsets.all(14), color: const Color(0xFFEAF2FB), child: Text(
        widget.isAdmin
          ? 'Admin AI: draft MCQs, explanations, notes and summaries. Verify official notices before publishing.'
          : 'Ask entry-test questions in Urdu or English. Use the microphone to speak and the speaker button to hear answers.',
        style: const TextStyle(color: navy),
      )),
      Expanded(child: messages.isEmpty
        ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Ask your first question.\n\nAI answers require internet and Firebase AI Logic access.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54))))
        : ListView.builder(padding: const EdgeInsets.all(12), itemCount: messages.length, itemBuilder: (context, i) => Align(
          alignment: messages[i].$1 ? Alignment.centerRight : Alignment.centerLeft,
          child: Container(margin: const EdgeInsets.symmetric(vertical: 5), padding: const EdgeInsets.all(12), constraints: const BoxConstraints(maxWidth: 320), decoration: BoxDecoration(color: messages[i].$1 ? const Color(0xFFDCEBFA) : Colors.white, borderRadius: BorderRadius.circular(14)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SelectableText(messages[i].$2),
            if (!messages[i].$1) Align(alignment: Alignment.centerRight, child: IconButton(tooltip: 'Listen', onPressed: () => _speak(messages[i].$2), icon: const Icon(Icons.volume_up, color: blue))),
          ])),
        )),
      ),
      if (busy) const Padding(padding: EdgeInsets.all(8), child: LinearProgressIndicator()),
      SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(10, 8, 10, 10), child: Row(children: [
        IconButton.filledTonal(onPressed: busy ? null : _listen, tooltip: listening ? 'Stop recording' : 'Speak question', icon: Icon(listening ? Icons.mic : Icons.mic_none)),
        const SizedBox(width: 6),
        Expanded(child: TextField(controller: input, minLines: 1, maxLines: 4, enabled: !busy, decoration: const InputDecoration(hintText: 'Type your question...', border: OutlineInputBorder()))),
        const SizedBox(width: 6),
        IconButton.filled(onPressed: busy ? null : send, icon: const Icon(Icons.send)),
      ]))),
    ]),
  );
}
