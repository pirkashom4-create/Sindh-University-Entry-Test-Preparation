# Sindh University Entry Test Preparation

Flutter Android source project. App creator credit: **Om Pirkash**.

## Included in this source package
- Blue-and-white student/admin preview UI
- Firebase Core initialization scaffold and Firebase AI Logic text assistant scaffold
- Voice input (speech-to-text) and spoken answers (text-to-speech) scaffold
- Android launcher icon asset and launcher-icon configuration
- Firebase Android configuration file (`google-services.json`)

## Important status
This is a development preview, not a finished production app. Student/admin authentication, role permissions, Firestore-backed MCQs/tests/results, payment verification, notifications, and the full admin web portal are not yet implemented. Firebase AI Logic also requires the project-side setup and App Check configuration before live AI use. Do not publish this preview as a complete service.

## Build
Use the GitHub Actions workflow in `.github/workflows/android-apk.yml`. It extracts the source ZIP from the repository, creates the Android platform folder, configures Firebase, generates the launcher icon, and builds a release APK.


## Firebase authentication upgrade (setup required)
- Enable **Email/Password** in Firebase Console → Authentication → Sign-in method.
- Deploy `firestore.rules` in Firebase Console → Firestore Database → Rules before using real accounts. Review rules before production deployment.
- Student self-registration creates `students/{uid}`. Admin self-registration is disabled.
- To authorize the first admin, create the admin user in Firebase Authentication, then create `admins/{AUTH_UID}` in Firestore with fields `role: "super_admin"` and `active: true`. Never let students create or edit admin documents.
- The app does not yet implement the admin web portal, AI quotas, payment verification, push notifications, or all content-management modules. Firebase AI Logic also needs to be enabled/configured in the Firebase project before live AI requests work.


## Visual refresh
- Premium navy-to-blue welcome screen with custom icon, feature chips and clear student/admin actions.
- Refined dashboard hero card, rounded module tiles, clearer hierarchy and status notice.
- Consistent Material 3 colors, app bars and rounded form fields.
- Creator credit remains visible: Om Pirkash.
