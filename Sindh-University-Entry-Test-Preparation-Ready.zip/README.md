# Sindh University Entry Test Preparation

Flutter Android preview app for Sindh University entry-test preparation.

**Created by: Om Pirkash**

## Included in this source package
- Navy/blue student preparation UI
- Student and admin preview entry screens
- Firebase Core, Firebase AI Logic and Firebase App Check initialization
- Urdu/English AI tutor text chat
- Microphone speech-to-text and spoken AI responses
- Custom Android launcher icon
- GitHub Actions workflow that builds an APK from this ZIP archive

## Important limitations
This is an AI integration preview, not a production-ready student portal.
Login buttons currently open preview dashboards; real Firebase Authentication,
secure admin authorization, student accounts, database-backed MCQs/tests/results,
payments, daily AI quotas, notifications and admin permissions are not implemented.
Do not use the preview admin entry point for real administration.

Firebase AI Logic requires internet. App Check is enabled. A direct release APK
may require Play Integrity configuration and supported Play distribution to pass
App Check. Speech recognition and Urdu/English voice output depend on Android
speech services and installed voices.

Never add a Gemini API key to the Android app.

## Build
Upload this ZIP to the root of the GitHub repository, then create the workflow
file at `.github/workflows/android-apk.yml` using the separate workflow text
provided with this project. Open GitHub Actions and run **Build Android APK**.
